/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javabasics1;

import java.util.Arrays;

/**
 *
 * @author macstudent
 */
public class hello {
    
    public static void main(String...args)
    {
       int k =90;
       float perc;
       char vo = 'd';
       
    
       
       
       System.out.println( k );
       perc = 78.9f;
       System.out.println(perc);
        System.out.println( "perc" + perc);
        k = 'b';
                System.out.println(k);
                if(k > 70)
                {
                    System.out.println("more than this");
                }
    else
                {
                    System.out.println("no");
                }
                vo ='a';
                switch(vo)
                {
                    case ('a'| 'i'|'o'):
                    //case 'i':
                    //case 'o':
                    System.out.println("vowel");
                    break;
                    default:
                        System.out.println("not");
                }
    switch(k)
    {
        case 10:
            System.out.println("value =10");
            case 20:
            System.out.println("value =20");
            case 30:
            System.out.println("value =30");
            default:
            System.out.println("no match");
            break;
         
    }
    
    String pro = "alberta";
    switch(pro)
    {
        case "ontario":
            System.out.println("on");
            break;
        case "alberta":
            System.out.println("ab");
        default:
            System.out.println("unavailable");
            break;
            
    
    }
    int numbers[] = new int [5];
    int i;
    for(i=0; i<numbers.length;i++)
    {
        numbers[i] = (int)(Math.random()*100);
        System.out.println(numbers[i]);
    }
    double PI_VALUE = Math.PI;
   double power = Math.pow(2,3);
   Math.sqrt(144);
   Math.abs(PI_VALUE);
   float grades[][]= new float[3][4];
   for(i=0;i<3;i++)
   {
       for(int j = 0;j<4;j++)
       {
           grades[i][j] = 10.0f;
           
       }
   }
     int randomNo[] = new int[10];
     for(i=0;i<10;i++)
     {
         randomNo[i] = (int)(Math.random()*10);
         System.out.println("no" + (i+1)+ "=" + randomNo[i]);
     }
    Arrays.sort(randomNo);
    {
        for(i=0;i<10;i++)
        {
            System.out.println("no" + (i+1)+ "=" + randomNo[i]);
        }
        int u,p;
        
            for(i=0;i<=6;i++)
            {
                for(p=0; p<=i;p++)
                {
                    System.out.println("*");
                }
                {
                    System.out.println();
                }
                
                        
     
     