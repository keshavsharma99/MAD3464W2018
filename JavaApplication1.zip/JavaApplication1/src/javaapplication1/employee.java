/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author macstudent
 */
import java.io.Serializable;  
public class employee implements Serializable{  
 public String address;  
public String name; 
public int ssn;
int number;
 public void mailCheck()
 {
     System.out.println("mailing a check to" + name +"" + address);
 }
    
}
