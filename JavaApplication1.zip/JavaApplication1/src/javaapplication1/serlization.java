/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.io.*;

/**
 *
 * @author macstudent
 */
public class serlization {
    
public static void main(String...args)
{
    employee e = new employee();
    e.name = "kk";
    e.address = "swdsede";
            e.ssn = 123444;
                    e.number = 12;

try
{ FileOutputStream fileout = new FileOutputStream("employee.txt");
 ObjectOutputStream out = new ObjectOutputStream(fileout);
out.writeObject(e);
out.close();
fileout.close();

    System.out.printf("text file");
}
catch(IOException i)
{
    i.printStackTrace();
}}}